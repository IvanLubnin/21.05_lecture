package fi_tamk.web_ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebExApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(WebExApplication.class, args);
	}

}
