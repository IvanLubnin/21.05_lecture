package fi_tamk.web_ex.repositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import fi_tamk.web_ex.entities.HistoryRecord;


@Repository
public interface HistoryRecordRepository 
    extends CrudRepository<HistoryRecord, Long> 
{
    
}
