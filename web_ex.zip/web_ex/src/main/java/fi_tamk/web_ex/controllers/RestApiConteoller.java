package fi_tamk.web_ex.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fi_tamk.web_ex.entities.HistoryRecord;
import fi_tamk.web_ex.services.HistoryRecordService;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RestApiConteoller 
{
    
    @Autowired
    private HistoryRecordService historyRecordService;

    @GetMapping("/test")
    public String test()
    {
        return "Hello world";
    }

    @GetMapping("/sum/{a}/{b}")
    public Long sum(@PathVariable Long a,@PathVariable Long b)
    {
        return a+b;
    }

    @PostMapping("/history_records")
    public HistoryRecord saveHistoryRecord(@RequestBody HistoryRecord hr) {
        return historyRecordService.saveHistoryRecord(hr);
    }

    @GetMapping("/history_records")
    public List<HistoryRecord> getHistoryRecords(){
        return historyRecordService.getHistoryRecords();
    }

}
