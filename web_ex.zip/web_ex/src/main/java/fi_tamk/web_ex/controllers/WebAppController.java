package fi_tamk.web_ex.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.Date;

@Controller
@RequestMapping (path = "/")
public class WebAppController 
{
    @RequestMapping("/greeting")
    public String greetings(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model)
    {
        model.addAttribute("name","Peter");
        model.addAttribute("current_date", new Date());
        return "greeting";
    }

    @RequestMapping("/calculator")
    public String calculator (Model model)
    {
        return "calculator";
    }
}
