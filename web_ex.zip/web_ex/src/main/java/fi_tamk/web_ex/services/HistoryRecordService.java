package fi_tamk.web_ex.services;
import java.util.List;

import fi_tamk.web_ex.entities.HistoryRecord;

public interface HistoryRecordService 
{
    HistoryRecord saveHistoryRecord(HistoryRecord historyRecord);

    List<HistoryRecord> getHistoryRecords();
}
