package fi_tamk.web_ex.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import fi_tamk.web_ex.entities.HistoryRecord;
import fi_tamk.web_ex.repositories.HistoryRecordRepository;

@Service
public class HistoryRecordServiceImpl 
{
    @Autowired
    private HistoryRecordRepository historyRecordRepository;

    HistoryRecord saveHistoryRecord(HistoryRecord historyRecord)
    {
        return historyRecordRepository.save(historyRecord);
    }

    List<HistoryRecord> getHistoryRecords()
    {
        return (List<HistoryRecord>) historyRecordRepository.findAll(); 
    }
}
