package fi_tamk.web_ex.entities;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import java.util.Date;
import jakarta.persistence.GenerationType;

@Entity
public class HistoryRecord {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private long number1;
    private long number2;
    private String operator; 
    private long result;
    private Date timestamp;

    public HistoryRecord(long number1, long numbrer2, String operator, long result)
    {
        this.number1 = number1;
        this.number2 = number2;
        this.operator = operator;
        this.result = result;
    }

    public long getId() 
    {
        return id;
    }

    public long getNumber1() 
    {
        return number1;
    }

    public long getNumber2() 
    {
        return number2;
    }

    public String getOperator() 
    {
        return operator;
    }

    public long getResult() 
    {
        return result;
    }

    public Date getTimestamp() 
    {
        return timestamp;
    }

    public void setId(long id) 
    {
        this.id = id;
    }

    public void setNumber1(long number1) 
    {
        this.number1 = number1;
    }

    public void setNumber2(long number2) 
    {
        this.number2 = number2;
    }

    public void setOperator(String operator) 
    {
        this.operator = operator;
    }

    public void setResult(long result) 
    {
        this.result = result;
    }

    public void setTimestamp(Date timestamp) 
    {
        this.timestamp = timestamp;
    }

    
}